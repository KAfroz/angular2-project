"use strict";

import { Component } from "@angular/core";

@Component({
    selector: "screen2",
    templateUrl: "./screen2.component.html",
})
export class Screen2Component {
    constructor() {
        // constructor
    }
}
